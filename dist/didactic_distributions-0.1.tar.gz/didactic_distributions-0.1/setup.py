from setuptools import setup

setup(name='didactic_distributions',
      version='0.1',
      description='Gaussian Distributions',
      packages=['didactic_distributions'],
      zip_safe=False)